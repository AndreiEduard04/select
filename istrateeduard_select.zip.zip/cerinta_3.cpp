// Initializarea minimului cu primul
#include<iostream>
using namespace std;
int v[100];
int n;
int minim;
int read_data()
{
    cout << "n ="; cin >> n;
    for(int i = 1; i<=n; i++)
    {
        cout << "V[" << i << "]=";
        cin >> v[i];
    }

}

int sort_data()
{
    for (int i = 1; i <= n-1; i++){
            if (v[i] < v[i+1]){
            minim = v[i];
                }
                cout << minim;
        }
}
print_data()
{
    for(int i = 1; i<= n; i++)
    {

    }
}

int main()
{
 read_data();
 sort_data();
 print_data();
}
